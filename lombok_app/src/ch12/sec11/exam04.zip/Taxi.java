package ch12.sec11.exam04;

public class Taxi extends Car {

	@Override
	void seat() {
		System.out.println("택시의 좌석 수 : 5");
	}

}
